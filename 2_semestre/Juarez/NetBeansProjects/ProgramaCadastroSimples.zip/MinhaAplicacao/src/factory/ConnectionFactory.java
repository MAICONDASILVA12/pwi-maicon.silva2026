package factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    public Connection getConnection() {
        try {
            // Caso seu MySQL tenha senha, insira dentro das ultimas aspas ""
            // Se der erro de fuso horario no Connector/J 8+, use:
            // "jdbc:mysql://localhost/projetojava?useTimezone=true&serverTimezone=UTC"
            return DriverManager.getConnection("jdbc:mysql://localhost/projetojava", "root", "");
        } catch (SQLException excecao) {
            throw new RuntimeException(excecao);
        }
    }
}
