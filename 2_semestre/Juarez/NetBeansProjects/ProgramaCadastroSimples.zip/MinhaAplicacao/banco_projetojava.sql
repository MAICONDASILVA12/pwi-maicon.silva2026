CREATE DATABASE IF NOT EXISTS projetojava;
USE projetojava;

CREATE TABLE IF NOT EXISTS usuario (
    id BIGINT(10) AUTO_INCREMENT,
    nome VARCHAR(255),
    cpf VARCHAR(255),
    email VARCHAR(255),
    telefone VARCHAR(255),
    PRIMARY KEY (id)
);
